package com.arms.domain.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;

@Data
@Entity
public class Hello {
	
	@Id
	@GeneratedValue
	private int id;
	
	@NotEmpty
	private String name;
	
}

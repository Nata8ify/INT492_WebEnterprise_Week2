package com.arms.app.hello;

import org.apache.log4j.spi.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.arms.domain.entity.Hello;
import com.arms.domain.repository.HelloRepository;

import ch.qos.logback.classic.Logger;

@Controller
@RequestMapping("")
public class HelloController {
	
	org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(HelloController.class);
	
	@Autowired
	HelloRepository helloRepository;

	@RequestMapping(value={"list",""}, method = RequestMethod.GET )
	public ModelAndView index(ModelAndView mav){
		mav.addObject("list", helloRepository.findAll());
		mav.setViewName("hello/list");
		return mav;
	}
	
	@RequestMapping(value="update/{id}", params="form", method = RequestMethod.GET )
	public ModelAndView update(@PathVariable("id")int id, ModelAndView mav){
		logger.info("id", id);
		mav.setViewName("hello/update");
		mav.addObject("hello", helloRepository.findOne(id));
		return mav;
	}
	
	@RequestMapping(value="delete/{id}", method = RequestMethod.GET )
	public String delete(@PathVariable("id")int id){
		logger.info("id", id);
		helloRepository.delete(id);
		return "redirect:/list";
	}
	
	@RequestMapping(value="create", params="form", method = RequestMethod.GET )
	public String create(){
		
		return "hello/create";
	}
	
	@RequestMapping(value="create", method = RequestMethod.POST )
	public String doneCreate(@RequestParam("name")String name){
		Hello hello = new Hello();
		hello.setName(name);
		helloRepository.save(hello);
		return "redirect:/list";
	}
	
	@RequestMapping(value="update", method = RequestMethod.POST )
	public String doneUpdate(@RequestParam("name")String name, @RequestParam("id")int id){
		Hello hello = new Hello();
		hello.setId(id);
		hello.setName(name);
		helloRepository.save(hello);
		return "redirect:/list";
	}
}
